# anjir_client — Minecraft 1.21.4 + Fabric

This repository is configured to build the Fabric client mod with Java 21 and GitHub Actions.

## Build locally

1. Install a 64-bit JDK 21.
2. Open a terminal in the repository folder.
3. Run:

   **Windows**
   ```bat
   gradlew.bat clean build
   ```

   **Linux/macOS**
   ```bash
   chmod +x ./gradlew
   ./gradlew clean build
   ```

The output JARs are created in `build/libs/`. Use the regular mod JAR, not the `-sources.jar`.

## Build on GitHub

1. Create a GitHub repository named `anjir_client`.
2. Upload/push the contents of this folder to the repository.
3. Open the **Actions** tab. Each push and pull request runs the build workflow.
4. Open a successful run and download the `anjir_client-minecraft-1.21.4` artifact.

## Important compatibility note

The original project was configured for Minecraft 26.2 and Java 25. This setup changes Gradle, Fabric Loader/API, metadata, and Java toolchain to Minecraft 1.21.4 + Fabric + Java 21. Because Minecraft APIs changed between versions, some of the original Java source code may still need version-specific fixes. GitHub Actions will report any remaining compile errors in the build log.
